Stylish Enterprises Android Studio Project

This is a source project for building an Android APK, not a precompiled APK.
Open this folder in Android Studio. Allow Gradle sync and install the Android SDK platform/build tools requested by Android Studio.
Then choose Build > Build Bundle(s) / APK(s) > Build APK(s).

Expected debug APK path after a successful build:
app/build/outputs/apk/debug/app-debug.apk

The app opens the included product catalogue offline in a WebView and includes the Excel file in app assets.
Retail prices are draft estimates. Verify prices, products, specifications, images and claims before publishing.
This project has not been built, tested on devices, signed for release, or published to Google Play.
